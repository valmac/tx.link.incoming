namespace SampleSmartCandles
{
	enum CandleTypes
	{
		TimeFrame,
		Tick,
		Volume,
		Range,
	}
}