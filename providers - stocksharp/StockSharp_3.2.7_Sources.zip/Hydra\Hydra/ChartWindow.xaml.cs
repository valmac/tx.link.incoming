﻿namespace StockSharp.Hydra
{
	partial class ChartWindow
	{
		public ChartWindow()
		{
			InitializeComponent();
		}
	}
}