namespace SampleCandles
{
	enum CandleTypes
	{
		TimeFrame,
		Tick,
		Volume,
		Range,
	}
}