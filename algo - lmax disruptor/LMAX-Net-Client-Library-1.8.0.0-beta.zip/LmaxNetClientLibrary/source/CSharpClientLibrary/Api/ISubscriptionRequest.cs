namespace Com.Lmax.Api
{
    /// <summary>
    /// Base interface for all subscription requests.
    /// </summary>
    public interface ISubscriptionRequest : IRequest
    {
    }
}
