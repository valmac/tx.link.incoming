namespace Com.Lmax.Api.Account
{
    ///<summary>
    /// Subscribe to all requests for heartbeats.
    ///</summary>
    public class HeartbeatSubscriptionRequest : AccountSubscriptionRequest
    {        
    }
}